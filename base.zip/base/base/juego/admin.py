from django.contrib import admin

from .models import Entrenador, Monstruo


@admin.register(Entrenador)
class EntrenadorAdmin(admin.ModelAdmin):
    list_display = ("nombre", "email", "creado")
    search_fields = ("nombre", "email")


@admin.register(Monstruo)
class MonstruoAdmin(admin.ModelAdmin):
    list_display = ("nombre", "tipo", "nivel", "hp", "ataque", "defensa", "entrenador")
    list_filter = ("tipo", "entrenador")
    search_fields = ("nombre",)


# TODO: registra aqui Item (diamante) y Batalla (oro) cuando los crees.
