"""
Tests de la Arena de Monstruos.

Ejecutar:  python manage.py test juego -v 2

Los tests de abajo ya pasan con el proyecto base. Al final del archivo hay una
lista de los tests que TU tienes que escribir: son parte de la evaluacion.
"""
from django.test import TestCase
from django.urls import reverse

from .combate import pelear
from .models import Entrenador, Monstruo


class BaseDatos(TestCase):
    def setUp(self):
        self.entrenador = Entrenador.objects.create(nombre="Ash", email="ash@inacap.cl")
        self.fuego = Monstruo.objects.create(
            nombre="Pyroclasto",
            tipo="fuego",
            hp=120,
            ataque=70,
            defensa=40,
            entrenador=self.entrenador,
        )
        self.planta = Monstruo.objects.create(
            nombre="Raizul",
            tipo="planta",
            hp=140,
            ataque=50,
            defensa=60,
            entrenador=self.entrenador,
        )


class ModeloTests(BaseDatos):
    def test_str_incluye_el_nombre(self):
        self.assertIn("Pyroclasto", str(self.fuego))

    def test_costo_stats(self):
        # 70 + 40 + 120/2 = 170
        self.assertEqual(self.fuego.costo_stats(), 170)

    def test_ventaja_de_tipo(self):
        self.assertTrue(self.fuego.es_fuerte_contra(self.planta))
        self.assertFalse(self.planta.es_fuerte_contra(self.fuego))


class CombateTests(BaseDatos):
    def test_combate_es_reproducible_con_semilla(self):
        uno = pelear(self.fuego, self.planta, semilla=42)
        otro = pelear(self.fuego, self.planta, semilla=42)
        self.assertEqual(uno["ganador"], otro["ganador"])
        self.assertEqual(uno["turnos"], otro["turnos"])


class CrudTests(BaseDatos):
    def test_listado_muestra_monstruos(self):
        respuesta = self.client.get(reverse("juego:lista"))
        self.assertEqual(respuesta.status_code, 200)
        self.assertContains(respuesta, "Pyroclasto")

    def test_crear_monstruo(self):
        datos = {
            "nombre": "Chispazo",
            "tipo": "electrico",
            "emoji": "⚡",
            "hp": 100,
            "ataque": 60,
            "defensa": 40,
            "entrenador": self.entrenador.pk,
        }
        respuesta = self.client.post(reverse("juego:crear"), datos)
        self.assertEqual(respuesta.status_code, 302)
        self.assertTrue(Monstruo.objects.filter(nombre="Chispazo").exists())

    def test_nombre_muy_corto_es_rechazado(self):
        datos = {
            "nombre": "AB",
            "tipo": "agua",
            "emoji": "\U0001f30a",
            "hp": 100,
            "ataque": 50,
            "defensa": 50,
            "entrenador": self.entrenador.pk,
        }
        self.client.post(reverse("juego:crear"), datos)
        self.assertFalse(Monstruo.objects.filter(nombre="AB").exists())


# --------------------------------------------------------------------------- #
# TODO: tests que debes escribir tu (uno por cada funcionalidad nueva)
# --------------------------------------------------------------------------- #
# BRONCE
#   - test_detalle_responde_200
#   - test_editar_cambia_el_ataque
#   - test_eliminar_requiere_post  (un GET NO debe borrar nada)
# PLATA
#   - test_rechaza_monstruo_sobrecargado  (hp=250, ataque=120, defensa=120)
#   - test_busqueda_filtra
# ORO
#   - test_pelea_guarda_batalla
#   - test_no_se_puede_pelear_contra_si_mismo
#   - test_ranking_cuenta_victorias
#   - test_ranking_sql_devuelve_las_mismas_filas_que_el_orm
# DIAMANTE
#   - test_items_suman_al_ataque
#   - test_entrenar_se_bloquea_al_pasar_el_presupuesto
#   - test_api_ranking_entrega_json
