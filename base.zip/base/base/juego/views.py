"""
Vistas de la Arena de Monstruos.

YA ESTA HECHO:
    lista()   -> el READ del CRUD (sin filtros todavia)
    crear()   -> el CREATE del CRUD
    entrenador_nuevo()

TU TRABAJO (en este orden):
    TODO BRONCE:   detalle(), editar(), eliminar()
    TODO PLATA:    busqueda, filtro por tipo, orden y paginacion en lista()
    TODO ORO:      arena(), ranking(), ranking_sql(), historial()
    TODO DIAMANTE: entrenar(), api_ranking()

Recuerda registrar cada vista nueva en juego/urls.py.
"""
from django.contrib import messages
from django.shortcuts import get_object_or_404, redirect, render

from .forms import EntrenadorForm, MonstruoForm
from .models import Entrenador, Monstruo

POR_PAGINA = 8


# --------------------------------------------------------------------------- #
# READ
# --------------------------------------------------------------------------- #
def lista(request):
    """
    Muestra todos los monstruos.

    TODO PLATA: agrega
      1. busqueda por nombre con request.GET.get("q") y filter(nombre__icontains=...)
      2. filtro por tipo
      3. orden configurable (nombre / mayor ataque / mayor hp)
      4. paginacion con django.core.paginator.Paginator (POR_PAGINA)
    La plantilla lista.html ya tiene el formulario de filtros listo para usarse.
    """
    monstruos = Monstruo.objects.select_related("entrenador").all()
    contexto = {
        "monstruos": monstruos,
        "tipos": Monstruo.TIPOS,
        "total": monstruos.count(),
    }
    return render(request, "juego/lista.html", contexto)


# TODO BRONCE: implementa detalle(request, pk)
#   - usa get_object_or_404(Monstruo, pk=pk)
#   - renderiza "juego/detalle.html" (la plantilla tambien la creas tu)


# --------------------------------------------------------------------------- #
# CREATE / UPDATE / DELETE
# --------------------------------------------------------------------------- #
def crear(request):
    if not Entrenador.objects.exists():
        messages.warning(
            request, "Primero crea un entrenador: no hay a quien asignarle el monstruo."
        )
        return redirect("juego:entrenador_nuevo")

    form = MonstruoForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        monstruo = form.save()
        messages.success(request, f"{monstruo.nombre} se unio a la arena.")
        return redirect("juego:lista")
    return render(
        request, "juego/formulario.html", {"form": form, "titulo": "Reclutar monstruo"}
    )



def detalle(request, pk):
    monstruo = get_object_or_404(
        Monstruo.objects.select_related("entrenador"),
        pk=pk
    )

    return render(
        request,
        "juego/detalle.html",
        {"monstruo": monstruo}
    )

def editar(request, pk):
    monstruo = get_object_or_404(Monstruo, pk=pk)

    form = MonstruoForm(
        request.POST or None,
        instance=monstruo
    )

    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(
            request,
            f"{monstruo.nombre} fue actualizado correctamente."
        )
        return redirect("juego:detalle", pk=monstruo.pk)

    return render(
        request,
        "juego/formulario.html",
        {
            "form": form,
            "titulo": f"Editar {monstruo.nombre}"
        }
    )

def eliminar(request, pk):
    monstruo = get_object_or_404(Monstruo, pk=pk)

    if request.method == "POST":
        nombre = monstruo.nombre
        monstruo.delete()

        messages.success(
            request,
            f"{nombre} fue eliminado correctamente."
        )

        return redirect("juego:lista")

    return render(
        request,
        "juego/confirmar_eliminar.html",
        {"monstruo": monstruo}
    )


# TODO BRONCE: implementa eliminar(request, pk)
#   - con GET muestra la plantilla de confirmacion "juego/confirmar_eliminar.html"
#   - con POST llama a monstruo.delete() y redirige al listado
#   Importante: borrar SIEMPRE con POST, nunca con un simple enlace GET.


def entrenador_nuevo(request):
    form = EntrenadorForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Entrenador registrado.")
        return redirect("juego:crear")
    return render(
        request,
        "juego/formulario.html",
        {"form": form, "titulo": "Registrar entrenador"},
    )


# --------------------------------------------------------------------------- #
# TODO ORO: el juego
# --------------------------------------------------------------------------- #
# def arena(request):
#     """
#     1. Usa ArenaForm (lo tienes que crear en forms.py) para elegir dos monstruos.
#     2. Llama a pelear(a, b) de juego/combate.py  <- el motor ya esta escrito.
#     3. Guarda el resultado en la tabla Batalla:
#            Batalla.objects.create(
#                monstruo_a=a, monstruo_b=b, ganador=resultado["ganador"],
#                turnos=resultado["turnos"],
#                bitacora="\n".join(resultado["bitacora"]),
#            )
#     4. Renderiza "juego/arena.html" con el resultado.
#     """


# def ranking(request):
#     """
#     Tabla de posiciones con el ORM. Pista:
#         from django.db.models import Count
#         Monstruo.objects.annotate(ganadas=Count("batallas_ganadas"))
#                         .order_by("-ganadas", "nombre")
#     """


# def ranking_sql(request):
#     """
#     El MISMO ranking, pero escrito en SQL y ejecutado por mysqlclient:
#         from django.db import connection
#         with connection.cursor() as cursor:
#             cursor.execute("SELECT ...")
#             filas = cursor.fetchall()
#     Necesitas un INNER JOIN con juego_entrenador, un LEFT JOIN con
#     juego_batalla, GROUP BY y COUNT. Muestra la consulta en la pagina.
#     """


# def historial(request):
#     """Lista paginada de las batallas, de la mas nueva a la mas antigua."""


# --------------------------------------------------------------------------- #
# TODO DIAMANTE
# --------------------------------------------------------------------------- #
# def entrenar(request, pk):
#     """Sube +1 nivel y +3/+3/+5 stats, SOLO si no se pasa del presupuesto."""


# def api_ranking(request):
#     """Devuelve el ranking en JSON con JsonResponse."""
