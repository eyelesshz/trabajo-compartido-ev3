"""
Modelos de la Arena de Monstruos.

LO QUE YA ESTA HECHO:
    - Entrenador
    - Monstruo (con su ForeignKey a Entrenador)

LO QUE TIENES QUE HACER (busca los TODO):
    - TODO PLATA:    validar el presupuesto de estadisticas en clean()
    - TODO ORO:      el modelo Batalla
    - TODO DIAMANTE: el modelo Item y el ManyToManyField items en Monstruo

Cada vez que cambies este archivo:
    python manage.py makemigrations
    python manage.py migrate
"""
from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models
from django.urls import reverse

# Cada tipo es fuerte contra el tipo indicado: el dano se multiplica por 1.25.
VENTAJAS = {
    "fuego": "planta",
    "planta": "agua",
    "agua": "fuego",
    "electrico": "agua",
    "roca": "electrico",
    "sombra": "roca",
}

# Presupuesto de estadisticas: evita monstruos invencibles.
PRESUPUESTO_STATS = 250


class Entrenador(models.Model):
    nombre = models.CharField(max_length=80)
    email = models.EmailField(unique=True)
    creado = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["nombre"]
        verbose_name_plural = "entrenadores"

    def __str__(self):
        return self.nombre


# TODO DIAMANTE: crea el modelo Item con los campos
#   nombre (unico), descripcion, bonus_ataque, bonus_defensa
# y luego agrega en Monstruo:
#   items = models.ManyToManyField(Item, blank=True, related_name="monstruos")


class Monstruo(models.Model):
    TIPOS = [
        ("fuego", "Fuego"),
        ("agua", "Agua"),
        ("planta", "Planta"),
        ("electrico", "Electrico"),
        ("roca", "Roca"),
        ("sombra", "Sombra"),
    ]

    nombre = models.CharField(max_length=60, unique=True)
    tipo = models.CharField(max_length=20, choices=TIPOS)
    emoji = models.CharField(
        max_length=8, default="\U0001f47e", help_text="Un emoji que lo represente"
    )
    # TODO DIAMANTE: la foto del monstruo. Son cinco pasos, en este orden:
    #   1) pip install Pillow            (ImageField no funciona sin Pillow)
    #   2) este campo:
    #        foto = models.ImageField(upload_to="monstruos/%Y/%m/",
    #                                 blank=True, null=True)
    #      y despues makemigrations + migrate
    #   3) en arena/settings.py:
    #        MEDIA_URL = "media/"
    #        MEDIA_ROOT = BASE_DIR / "media"
    #   4) en arena/urls.py, para que el servidor de pruebas las entregue:
    #        if settings.DEBUG:
    #            urlpatterns += static(settings.MEDIA_URL,
    #                                  document_root=settings.MEDIA_ROOT)
    #   5) en el formulario: enctype="multipart/form-data" en el <form> y
    #      request.FILES en la vista. Sin esos dos, la foto nunca llega.
    hp = models.PositiveIntegerField(
        default=100, validators=[MinValueValidator(50), MaxValueValidator(250)]
    )
    ataque = models.PositiveIntegerField(
        default=50, validators=[MinValueValidator(10), MaxValueValidator(120)]
    )
    defensa = models.PositiveIntegerField(
        default=50, validators=[MinValueValidator(10), MaxValueValidator(120)]
    )
    nivel = models.PositiveIntegerField(default=1)
    entrenador = models.ForeignKey(
        Entrenador, on_delete=models.PROTECT, related_name="monstruos"
    )
    creado = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["nombre"]
        # TODO PLATA: agrega un indice por tipo para que el filtro sea rapido:
        # indexes = [models.Index(fields=["tipo"], name="idx_monstruo_tipo")]

    def __str__(self):
        return f"{self.emoji} {self.nombre}"

    def get_absolute_url(self):
        return reverse("juego:detalle", args=[self.pk])

    # --- Reglas del juego ---------------------------------------------------
    def costo_stats(self):
        """Puntos gastados en estadisticas (el tope es PRESUPUESTO_STATS)."""
        return self.ataque + self.defensa + self.hp // 2

    # TODO PLATA: implementa clean() para que un monstruo no pueda pasarse del
    # presupuesto. Debe lanzar ValidationError con un mensaje claro.
    # Pista:
    #     from django.core.exceptions import ValidationError
    #     def clean(self):
    #         super().clean()
    #         if self.costo_stats() > PRESUPUESTO_STATS:
    #             raise ValidationError("...")

    @property
    def ataque_total(self):
        # TODO DIAMANTE: suma aqui los bonus de los items equipados.
        return self.ataque

    @property
    def defensa_total(self):
        # TODO DIAMANTE: suma aqui los bonus de los items equipados.
        return self.defensa

    @property
    def poder(self):
        return self.ataque_total + self.defensa_total + self.hp // 10 + self.nivel * 2

    def es_fuerte_contra(self, otro):
        return VENTAJAS.get(self.tipo) == otro.tipo

    # TODO ORO: una vez que exista el modelo Batalla, implementa
    # victorias() y derrotas() para mostrarlas en el detalle del monstruo.


# TODO ORO: crea el modelo Batalla con estos campos
#   monstruo_a  -> FK a Monstruo, related_name="batallas_como_a"
#   monstruo_b  -> FK a Monstruo, related_name="batallas_como_b"
#   ganador     -> FK a Monstruo, null=True, blank=True,
#                  on_delete=models.SET_NULL, related_name="batallas_ganadas"
#   turnos      -> PositiveIntegerField
#   bitacora    -> TextField(blank=True)
#   fecha       -> DateTimeField(auto_now_add=True)
# Agrega tambien un metodo lineas_bitacora() que devuelva self.bitacora.splitlines()
