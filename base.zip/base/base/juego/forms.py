from django import forms

from .models import Entrenador, Monstruo


class MonstruoForm(forms.ModelForm):
    """
    Formulario del CRUD.

    TODO DIAMANTE: cuando exista el ManyToMany con Item, agrega "items" a
    fields y usa el widget forms.CheckboxSelectMultiple().

    TODO DIAMANTE: agrega tambien "foto" a fields. Que sea una imagen de
    verdad lo revisa ImageField usando Pillow; lo que NO revisa es el peso,
    asi que escribe un clean_foto() que rechace archivos de mas de 2 MB
    (la propiedad es foto.size y viene en bytes).
    """

    class Meta:
        model = Monstruo
        fields = ["nombre", "tipo", "emoji", "hp", "ataque", "defensa", "entrenador"]
        widgets = {
            "nombre": forms.TextInput(attrs={"placeholder": "Ej: Pyroclasto"}),
            "emoji": forms.TextInput(attrs={"maxlength": 8}),
        }
        help_texts = {
            "hp": "Entre 50 y 250",
            "ataque": "Entre 10 y 120",
            "defensa": "Entre 10 y 120",
        }

    def clean_nombre(self):
        """Ejemplo de validacion de un campo puntual."""
        nombre = self.cleaned_data["nombre"].strip()
        if len(nombre) < 3:
            raise forms.ValidationError("El nombre debe tener al menos 3 letras.")
        return nombre


class EntrenadorForm(forms.ModelForm):
    class Meta:
        model = Entrenador
        fields = ["nombre", "email"]


# TODO ORO: crea ArenaForm, un forms.Form con dos ModelChoiceField
# (monstruo_a y monstruo_b) y un clean() que impida que un monstruo
# pelee contra si mismo.
